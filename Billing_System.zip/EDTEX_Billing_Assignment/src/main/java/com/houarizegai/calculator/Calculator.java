package com.houarizegai.calculator;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Calculator extends JFrame implements ActionListener {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Container con = getContentPane();
	JLabel prompt = new JLabel("Enter Amount");

	JLabel result = new JLabel();
	//add(result);
	JLabel result2 = new JLabel();
	/*result.setHorizontalAlignment(50);
	result.setVerticalAlignment(60);
    
    result2.setHorizontalAlignment(50); // set the horizontal alignement on the x axis !
    result2.setVerticalAlignment(65);
*/
	Font promptFont = new Font("Times", Font.BOLD, 12);
	Font resultFont = new Font("Times", Font.BOLD, 20);
	Font result2Font = new Font("Times", Font.BOLD, 20);

	JTextField input = new JTextField(20);
	
	JButton add = new JButton("Diamond Membership");
	JButton subtract = new JButton("Platinum Memebership ");
	JButton divide = new JButton("Regular Member");
	private final JLabel result_1 = new JLabel();
	private final JLabel result_1_1 = new JLabel();

	
	public Calculator(){
		
		super("Customer Billing");
		getContentPane().setBackground(new Color(204, 204, 255));
		setSize(500,500);
		con.setLayout(new FlowLayout());
		//prompt.setHorizontalAlignment(SwingConstants.LEFT);
		prompt.setFont(promptFont);
		result.setLocation(new Point(5, 3));
		result.setFont(resultFont);
		
		con.add(prompt);
		con.add(input);
		add.setLocation(new Point(1, 1));
		add.setForeground(new Color(0, 0, 51));
		add.setAlignmentY(Component.BOTTOM_ALIGNMENT);
		add.setAlignmentX(Component.RIGHT_ALIGNMENT);
		add.setIconTextGap(10);
		add.setVerticalAlignment(SwingConstants.BOTTOM);
		con.add(add);
		
		
			
			//action listeners
			add.addActionListener(this);
		result_1_1.setLocation(new Point(10, 6));
		result_1_1.setFont(new Font("Dialog", Font.BOLD, 20));
		
		getContentPane().add(result_1_1);
		divide.setBackground(new Color(240, 240, 240));
		divide.setHorizontalAlignment(SwingConstants.TRAILING);
		con.add(divide);
		divide.addActionListener(this);
		subtract.setVerticalAlignment(SwingConstants.TOP);
		con.add(subtract);
		subtract.addActionListener(this);
		result_1.setLocation(new Point(11,7));
		result_1.setFont(new Font("Dialog", Font.BOLD, 20));
		
		getContentPane().add(result_1);
		con.add(result);
		
		
	}
	
	public static void main(String[] args){
		
		Calculator demo = new Calculator();
		demo.setVisible(true);
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		Object source = e.getSource();
		if(source == add)
		{ 
			String ans1 = input.getText();
			double num1 = Double.parseDouble(ans1);
     			Double RESULT = num1*0.86*0.93;
			String res = new Double(RESULT).toString();
			result.setText("The offered Price of Diamond Membership is " + res);
			Double RESULT2 = num1-RESULT;
			String res2 = new Double(RESULT2).toString();
			result_1.setText("The Discounted Price of Diamond Membership is " + res2);
			Double RESULT3 = RESULT + 2000;
			String res3 = new Double(RESULT3).toString();
			result_1_1.setText("The Total Bill is " + res3);

		}
		
		if(source == subtract)
		{
			String ans1 = input.getText();
			double num1 = Double.parseDouble(ans1);
     			Double RESULT = num1*0.86*0.86;
     			String res = new Double(RESULT).toString();
			result.setText("The offered Price of Platinium Membership is " + res);	
			Double RESULT2 = num1-RESULT;
			String res2 = new Double(RESULT2).toString();
			result_1.setText("The Discounted Price of Platinium Membership is " + res2);
			Double RESULT3 = RESULT + 2000;
			String res3 = new Double(RESULT3).toString();
			result_1_1.setText("The Total Bill is " + res3);
		}
		if(source == divide)
		{
			String ans1 = input.getText();
			double num1 = Double.parseDouble(ans1);
     			Double RESULT = num1*0.86;
     			String res = new Double(RESULT).toString();
			result.setText("The offered Price of Regular Member is " + res);
			Double RESULT2 = num1-RESULT;
			String res2 = new Double(RESULT2).toString();
			result_1.setText("The Discounted Price of Regular Member is " + res2);
			Double RESULT3 = RESULT + 2000;
			String res3 = new Double(RESULT3).toString();
			result_1_1.setText("The Total Bill is " + res3);
		}
		
	}

}